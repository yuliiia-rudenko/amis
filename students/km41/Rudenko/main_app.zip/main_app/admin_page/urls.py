from django.conf.urls import url
from . import views
from django.contrib.auth import views as auth

urlpatterns = [

    url(r'^$', views.AdminPage.as_view(), name='admin_page_main'),

    url(r'^create_product/$', views.CreateProduct.as_view(), name='create_product'),

    url(r'^delete_product/(?P<pk>\d+)/$', views.DeleteProduct.as_view(), name='delete_product'),

    url(r'^edit_product/(?P<pk>\d+)/$', views.EditProduct.as_view(), name='edit_product'),

    url(r'^balance/(?P<pk>\d+)/$', views.AddBalance.as_view(), name='add_balance'),

    url(r'^confirms/$', views.Confirmation.as_view(), name='confirms'),

    url(r'^confirms/(?P<pk>\d+)/$', views.Confirmation.as_view(), name='confirms_pk'),

]
