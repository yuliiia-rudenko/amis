from django.shortcuts import render, redirect
from django.core.urlresolvers import reverse
from django.views import View
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.core.files.storage import FileSystemStorage

from django.db import transaction
from django.db import connection
from products.models import Product, Order
from accounts.models import UserProfile
from .forms import ProductForm

DEFAULT_PHOTO_DIR = 'products'
DEFAULT_PHOTO = 'no_product.png'
DEFAULT_PHOTO_PATH = '{dir}/{name}'.format(dir=DEFAULT_PHOTO_DIR, name=DEFAULT_PHOTO)

@method_decorator(login_required, name='dispatch')
class AdminPage(View):
    template_name = 'admin_page/main.html'

    def get(self, request):
        products = Product.objects.all()
        users = UserProfile.objects.all()
        return render(request, self.template_name, {'products': products, 'users': users})


@method_decorator(login_required, name='dispatch')
class CreateProduct(View):
    template_name = 'admin_page/create_product.html'

    def get(self, request):
        form = ProductForm()
        return render(request, self.template_name, {'form': form})

    def post(self, request):
        form = ProductForm(request.POST, request.FILES)
        if form.is_valid():
            name = request.POST.get('name')
            description = request.POST.get('description') or ''
            price = int(request.POST.get('price'))
            brend = request.POST.get('brend') or ''
            product_type = request.POST.get('product_type') or ''
            quantity = int(request.POST.get('quantity'))
            product_photo = request.FILES.get('product_photo')
            if not product_photo:
                product_photo = DEFAULT_PHOTO_PATH
            else:
                myfile = request.FILES.get('product_photo')
                fs = FileSystemStorage()
                filename = fs.save(product_photo, myfile)
                product_photo = DEFAULT_PHOTO_DIR + '/' + product_photo.name

            with transaction.atomic():
                cursor = connection.cursor()
                cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')

                cursor.callproc('PRODUCT_PACKAGE.NEW_PRODUCT', [
                    name, description, price, brend,
                    product_type, quantity, product_photo])

            # form.save()
            return redirect(reverse('admin_page:admin_page_main'))
        return render(request, self.template_name, {'form':form})


@method_decorator(login_required, name='dispatch')
class DeleteProduct(View):
    template_name = 'admin_page/delete_product.html'

    def post(self, request, pk):
        with transaction.atomic():
            cursor = connection.cursor()
            cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')

            cursor.callproc('PRODUCT_PACKAGE.DELETE_PRODUCT', [pk])

        # Product.objects.get(pk=pk).delete()
        return redirect(reverse('admin_page:admin_page_main'))


@method_decorator(login_required, name='dispatch')
class EditProduct(View):
    template_name = 'admin_page/edit_product.html'

    def get(self, request, pk):
        product = Product.objects.get(pk=pk)
        form = ProductForm(instance=product)
        return render(request, self.template_name, {'form': form})

    def post(self, request, pk):
        product = Product.objects.get(pk=pk)
        form = ProductForm(request.POST, request.FILES, instance=product)
        if form.is_valid():
            name = request.POST.get('name')
            description = request.POST.get('description') or ''
            price = int(request.POST.get('price'))
            brend = request.POST.get('brend') or ''
            product_type = request.POST.get('product_type') or ''
            quantity = int(request.POST.get('quantity'))
            product_photo = request.FILES.get('product_photo')
            if not product_photo:
                product_photo = DEFAULT_PHOTO_PATH
            else:
                product_photo = DEFAULT_PHOTO_DIR + '/' + product_photo.name
                myfile = request.FILES.get('product_photo')
                fs = FileSystemStorage()
                filename = fs.save(product_photo, myfile)

            with transaction.atomic():
                cursor = connection.cursor()
                cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')

                cursor.callproc('PRODUCT_PACKAGE.UPDATE_PRODUCT', [
                    pk, name, description, price, brend,
                    product_type, quantity, product_photo])

            # form.save()
            return redirect(reverse('admin_page:admin_page_main'))
        return render(request, self.template_name, {'form':form})


@method_decorator(login_required, name='dispatch')
class AddBalance(View):

    def post(self, request, pk):
        # with transaction.atomic():
        #     cursor = connection.cursor()
        #     cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')

        #     cursor.callproc('PRODUCT_PACKAGE.DELETE_PRODUCT', [pk])
        balance = int(request.POST.get('balance'))
        user = UserProfile.objects.raw("SELECT * FROM ACCOUNTS_USERPROFILE WHERE ID={}".format(pk))[0]
        
        with transaction.atomic():
            cursor = connection.cursor()
            cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')

            cursor.callproc('USER_BALANCE_PACKAGE.ADD_MONEY', [user.id, balance])

        # user.balance += balance
        # user.save()

        return redirect(reverse('admin_page:admin_page_main'))


@method_decorator(login_required, name='dispatch')
class Confirmation(View):
    template_name = 'admin_page/confirmation.html'

    def get(self, request):
        orders = Order.objects.filter(approved=False)

        return render(request, self.template_name, {'orders': orders})

    def post(self, request, pk):

        order = Order.objects.get(pk=pk)
        user_profile = UserProfile.objects.get(pk=order.user.id)
        product = Product.objects.get(pk=order.product.id)
        order_costs = order.quantity * product.price

        user_profile.balance -= order_costs
        user_profile.save()
        product.quantity -= order.quantity
        product.save()
        order.approved = True
        order.save()

        return redirect(reverse('admin_page:confirms'))
