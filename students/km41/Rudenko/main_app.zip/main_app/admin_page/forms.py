from products.models import Product
from django import forms
from django.forms.widgets import PasswordInput, NumberInput


class ProductForm(forms.ModelForm):
    name = forms.CharField(max_length=50, help_text='name')
    description = forms.CharField(max_length=50, required=False, help_text='description')
    price = forms.IntegerField(help_text='price', widget=NumberInput(attrs={'class':'validate', 'min':"1", 'max': "100"}))
    brend = forms.CharField(max_length=50, required=False, help_text='brend',)
    product_type = forms.CharField(max_length=50, required=False, help_text='price')
    quantity = forms.IntegerField(help_text='quantity', widget=NumberInput(attrs={'class':'validate', 'min':"1", 'max': "100"}))
    product_photo = forms.ImageField(required=False, help_text='product_photo')

    class Meta:
        model = Product
        fields = '__all__'

