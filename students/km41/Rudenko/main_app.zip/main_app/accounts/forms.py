from django import forms
from django.contrib.auth.forms import UserCreationForm

# from .models import Taxi
from .models import UserProfile

from django.forms.widgets import PasswordInput, TextInput
from django.core.files.images import get_image_dimensions


class UserProfileForm(UserCreationForm):
    username = forms.CharField(max_length=50, help_text='Username')
    first_name = forms.CharField(max_length=50, required=False, help_text='Optional')
    last_name = forms.CharField(max_length=50, required=False, help_text='Optional')
    email = forms.EmailField(max_length=50, help_text='Required',
        widget=TextInput(attrs={'class':'validate','placeholder': 'my_email@mail.com', 'pattern':"[A-Za-z0-9._]+@[A-Za-z0-9._]+\.[A-Za-z]{2,5}", 'title': "my_email@mail.com"}))
    user_photo = forms.ImageField(required=False, help_text='Optional')

    class Meta:
        model = UserProfile
        fields = ('username', 'first_name', 'last_name', 'email', 'password1',
            'password2', 'user_photo',
            )

    def save(self, commit=True):
        user = super(UserProfileForm, self).save(commit=False)
        user.email = self.cleaned_data['email']
        user.first_name = self.cleaned_data['first_name']
        user.last_name = self.cleaned_data['last_name']
        user.user_photo = self.cleaned_data['user_photo']

        user.save()

        return user

