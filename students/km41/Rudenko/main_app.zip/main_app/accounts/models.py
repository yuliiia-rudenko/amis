from django.db import models
from django.contrib.auth.models import AbstractUser
from django.conf import settings


class UserProfile(AbstractUser):
    user_photo = models.ImageField(
        upload_to='profile_images/',
        blank=True,
        default='profile_images/no_profile.jpg',
        verbose_name='File'
    )
    balance = models.PositiveIntegerField(default=100)

    class Meta(object):
        unique_together = ('email',)
