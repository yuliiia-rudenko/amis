from django.shortcuts import render, redirect
from .forms import UserProfileForm
from django.core.urlresolvers import reverse
from django.views import View


class SignUp(View):
    template_name = 'registration/registration.html'

    def get(self, request):
        form = UserProfileForm()
        return render(request, self.template_name, {'form':form})

    def post(self, request):
        form = UserProfileForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect(reverse('accounts:login'))
        return render(request, self.template_name, {'form':form})

