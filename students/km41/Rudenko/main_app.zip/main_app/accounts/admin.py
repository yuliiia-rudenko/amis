from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as DefaultUserAdmin

from .models import UserProfile


class UserAdmin(DefaultUserAdmin):
    fieldsets = (
        (None, {'fields': ('email', 'password')}),
        ('User info', {'fields': ('username', 'first_name', 'last_name', 'email', 'user_photo',
        	'balance', 'is_active', 'is_superuser', 'is_staff',)}),
    )    
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('username', 'first_name', 'last_name', 'email', 'password1', 'password2', 'user_photo',
            	'balance', 'is_active', 'is_superuser', 'is_staff')}
        ),
    )


admin.site.register(UserProfile, UserAdmin)
