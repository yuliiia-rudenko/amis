from django.shortcuts import render, redirect
from django.core.urlresolvers import reverse
from django.views import View
from accounts.models import UserProfile
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.db import transaction
from django.db import connection

from .models import Product, Order


class Products(View):
    template_name = 'products/all_products.html'

    def get(self, request):
        products = Product.objects.all()
        return render(request, self.template_name, {'products':products})


@method_decorator(login_required, name='dispatch')
class ProductsDetails(View):
    template_name = 'products/details.html'

    def get(self, request, pk):
        # product = Product.objects.get(pk=pk)

        cursor = connection.cursor()
        cursor.execute('SELECT "PRODUCT_NAME",\
                "PRODUCT_ID",\
                "PRODUCT_PHOTO",\
                "PRODUCT_DESCRIPTION",\
                "PRODUCT_TYPE",\
                "BREND",\
                "PRICE",\
                "QUANTITY"\
            FROM "PRODUCT_DETAILS" \
            WHERE "PRODUCT_ID" = {id}'.format(id=pk))

        PRODUCT_NAME, PRODUCT_ID, PRODUCT_PHOTO, PRODUCT_DESCRIPTION,\
        PRODUCT_TYPE, BREND, PRICE, QUANTITY = cursor.fetchone()

        context = {
            "PRODUCT_NAME": PRODUCT_NAME,
            "PRODUCT_ID": PRODUCT_ID,
            "PRODUCT_PHOTO": PRODUCT_PHOTO,
            "PRODUCT_DESCRIPTION": PRODUCT_DESCRIPTION,
            "PRODUCT_TYPE": PRODUCT_TYPE,
            "BREND": BREND,
            "PRICE": PRICE, 
            "QUANTITY": QUANTITY
        }

        return render(request, self.template_name, context)

    def post(self, request, pk):
        quantity = int(request.POST.get('quantity'))
        user = request.user
        # user_profile = UserProfile.objects.get(pk=user.id)
        user_profile = UserProfile.objects.raw("SELECT * FROM ACCOUNTS_USERPROFILE WHERE ID={}".format(user.id))[0]

        product = Product.objects.get(pk=pk)
        # product.quantity -= quantity
        # product.save()

        to_pay = quantity * product.price
        if user_profile.balance >= to_pay:
            # user_profile.balance -= to_pay
            # user_profile.save()

            with transaction.atomic():
                cursor = connection.cursor()
                cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')

                order_id = int(cursor.callproc('PACKAGE_ORDER.NEW_ORDER', [
                    user.id, product.id, quantity, ''])[-1])

            # order = Order.objects.create(user_id=user.id, product_id=pk, quantity=quantity)
            return redirect(reverse('products:order_details', args=(order_id,)))

        else:
            return render(request, 'orders/order-failed.html', {'product': product, 'quantity': quantity, 'to_pay': to_pay, 'balance': user_profile.balance})


@method_decorator(login_required, name='dispatch')
class Profile(View):
    template_name = 'profile/profile.html'

    def get(self, request, pk=None):
        is_own = False
        if not pk:
            pk = request.user.id
        if request.user.id == int(pk):
            is_own = True

        # user = UserProfile.objects.get(pk=pk)
        # orders = Order.objects.filter(user_id=user.id)
        user = UserProfile.objects.raw("SELECT * FROM ACCOUNTS_USERPROFILE WHERE ID={}".format(pk))[0]
        orders = Order.objects.raw("SELECT * FROM PRODUCTS_ORDER WHERE USER_ID={user_id}".format(user_id=user.id))
        return render(request, self.template_name, {'user':user, 'is_own': is_own, 'orders': orders})


@method_decorator(login_required, name='dispatch')
class OrderDetails(View):
    template_name = 'orders/order-details.html'

    def get(self, request, pk):
        # order = Order.objects.get(pk=pk)
        order = Order.objects.raw("SELECT * FROM PRODUCTS_ORDER WHERE ID={}".format(pk))[0]

        return render(request, self.template_name, {'order':order})

