from django.conf.urls import url
from . import views
from django.contrib.auth import views as auth

urlpatterns = [

    url(r'^all/$', views.Products.as_view(), name='all_products'),

    url(r'^details/(?P<pk>\d+)/$', views.ProductsDetails.as_view(), name='details'),

    url(r'^profile/$', views.Profile.as_view(), name='profile'),

    url(r'^profile/(?P<pk>\d+)/$', views.Profile.as_view(), name='profile_with_pk'),

    url(r'^order_details/(?P<pk>\d+)/$', views.OrderDetails.as_view(), name='order_details'),

]
