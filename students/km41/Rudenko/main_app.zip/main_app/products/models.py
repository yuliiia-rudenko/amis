from django.db import models
from django.conf import settings

class Product(models.Model):
    name = models.CharField(
        max_length=30,
        default='Noname',
    )
    description = models.CharField(
        max_length=255,
        blank=True,
        null=True,
    )
    price = models.PositiveIntegerField(
        null=True,
        blank=True,
        default=0,
    )
    brend = models.CharField(
        max_length=30,
        blank=True,
        null=True,
        default='Nobrend',
    )
    product_type = models.CharField(
        max_length=30,
        blank=True,
        null=True,
        default='Notype',
    )
    quantity = models.PositiveIntegerField(
        default=1,
    )
    product_photo = models.ImageField(
        upload_to='products/',
        blank=True,
        default='products/no_product.png',
    )

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Product"
        verbose_name_plural = "Products"


class Order(models.Model):
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        verbose_name='User',
        on_delete=models.SET_NULL,
        null=True,
    )
    product = models.ForeignKey(
        'Product',
        verbose_name='Product',
        on_delete=models.SET_NULL,
        null=True,
    )
    quantity = models.PositiveIntegerField(
        default=1,
    )
    approved = models.NullBooleanField(default=False)
    create_time = models.DateTimeField(
        'Created',
        auto_now_add=True,
        null=True,
    )

    def __str__(self):
        return 'Order of user {user} of {quantity} items of {product} on {create_time}'.format(
            user=self.user, quantity=self.quantity, product=self.product, create_time=self.create_time)

    class Meta:
        verbose_name = "Order"
        verbose_name_plural = "Orders"


